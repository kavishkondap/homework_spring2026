import pandas as pd
import plotly.graph_objects as go
from pathlib import Path

PLOT_X = "Train_EnvstepsSoFar"
PLOT_Y = "Eval_AverageReturn"

SAVE_NAME="part_4_eval_loss.png"

ckpt_dirs = {
    "Baseline (BGS = 5)":"/Users/kavish/Desktop/KAVISH/Berkeley/Sophomore Year/cs185/homework_spring2026/hw2/exp/HalfCheetah-v4_cheetah_baseline_sd185_20260225_200827",
    "No Baseline":"/Users/kavish/Desktop/KAVISH/Berkeley/Sophomore Year/cs185/homework_spring2026/hw2/exp/HalfCheetah-v4_cheetah_sd1_20260225_205554",
    "Baseline (BGS = 2)":"/Users/kavish/Desktop/KAVISH/Berkeley/Sophomore Year/cs185/homework_spring2026/hw2/exp/HalfCheetah-v4_cheetah_baseline_sd1_20260225_205838",
}

fig = go.Figure()

for label, dir in ckpt_dirs.items():
    df = pd.read_csv(Path(dir) / "log.csv")

    fig.add_trace(go.Scatter(x=df[PLOT_X], y=df[PLOT_Y], mode="lines", name=label))

fig.update_layout(
    title="Cheetah Average Eval Return",
    xaxis_title=PLOT_X,
    yaxis_title=PLOT_Y
)

fig.write_image(SAVE_NAME)
# fig.show()